# Nacreway / Underwater design handoff

Status: DESIGN ONLY. This directory adds zero playable content and changes no Magma file. The current player-delivered milestone remains separate from the65-form Magma candidate.89 forms is the proposed next total only after both milestones pass real acceptance.

Start with UNDERWATER_CHAPTER_BRIEF.md. Then read IMPLEMENTATION_AND_ACCEPTANCE.md before integrating any data. CREATURE_CARDS.md contains all24 form/command cards; TRIALS_AND_ACQUISITION.md contains all16 qualified trial outlines and8 repeat sources. These are developer-only solution documents, not player media.

Canonical compact JSON:

- underwater_allocation.json and allocation.schema.json: exact source-pinned namespaces, wire policy, resource estimates and capacities
- creature_forms.json and catalog_delta.json:24 schema2 forms,24 commands,16 explicit branch edges, trial bindings and append-only capabilities/gates
- ability_contracts.json: measured geometry, control, timing, damage and comparisons to old commands
- world_plan.json:8 connected areas, mandatory puzzles,8 quests and6 equipment sidegrades
- acquisition_contracts.json and trial_contracts.json: exact source, same-individual and retry contracts
- families.json: all8 immutable two-way family shapes
- completion_roadmap.json: bounded89→100→112→120→128 milestones, ending at72 retained,64 quests and48 gear

Reproducible checks from this directory:

    python -B validate_design.py
    python -B -m unittest -v test_design

build_design.py regenerates the compact JSON from this directory's authored specification, reading only the sibling adventure-legends-magma reference. It records new baseline hashes, so run it only after intentionally reviewing any changed Magma source. render_cards.py regenerates human-readable cards. Both scripts write only here. No GitHub, Library, browser or user-computer actions were used.

Checks cover the existing catalog JSON Schema and semantic validator, an in-memory proposed revision6 enablement policy, unchanged old catalog rows, immutable identity/topology, exact namespace disjointness, event/flag/bank/OBJ/ROM/RAM budgets, all256 first-branch combinations,16 qualified path identities, same-attempt nonduplication, per-instance training, admission boundaries and the main-route dependency graph.

They do not prove native map solvability, implemented hitbox distinctness, pixel-art readability, save migration acceptance, controller acquisition or59.73Hz performance. Those are explicit implementation acceptance gates. The Python transaction model is not cartridge code or a replacement save validator.

Every text/JSON/script file is under90,000 bytes. No oversized merged catalog file is produced; structural and proposed enablement validation merge data in memory. Final hashes are recorded in artifact_manifest.json.
